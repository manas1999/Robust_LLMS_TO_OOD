import pandas as pd

# Load the dataset
data_zero_shot = pd.read_csv('/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/Prompts/Zero_shot/flipkart_prompts_sentiment.csv', encoding='latin1')
print("data_zero_shot columns: ", data_zero_shot.columns)
print("data_zero_shot shape: ", data_zero_shot.shape)

## creating sample_text.txt file
# Reviews and summaries
reviews_and_summaries = [
    ("super!", "Tri tip sandwich Best ever Smokey juicy yummy Serves every Saturday and Sunday We enjoy the backcountry atmosphere Pretty bomb onion rings as well"),
    ("super!", "This shop is a gem Tom is an outstanding barber and an engaging conversationalist Quality is great prices reasonable and competitive Plenty of free parking and of course plenty of TV sets This shop exemplifies qualityhead on over for a great haircut"),
    ("super!", "Delicious Came here with a large group and not a single person disliked their meal I got the nachos piggy mac and skillet pecan cobbler Holy cow Every course was fantastic and I enjoyed every single bite The nachos were fully loaded and were outstanding Every bite had some goodness The macncheese was anything but plain and well seasoned with plenty of meat The skillet cobbler This stole the show The perfect way to end a nearly perfect meal It was sweet salty and had some ice cream on top I sometimes dream of having this again Ifwhen I come back to Nashville I will certainly stop at Pucketts Gro to get some more Pecan Cobbler and BBQ"),
    ("super!", "The Mole is outstanding Tequila ice cream is killer Bring your own cerveca and skip the chain Mexican place down the road This is the real deal"),
    ("super!", "Overall the entire place is Outdated The quality and resolution of the movie is very bad No imax My TV has better quality seats are not comfortable and cant find your seat because the stickers peeled off Crumbs and food on the seats and floor They add gratuity to the bill which is not worth it They only take your order one time before the movie They dont come back to check on you during the movie or take your empty plates and cups etc Im sure i left somethings out but longstory short i Will be going to Hyde Park cinebistro next time"),
    ("super!", "I made a great review of all the issues from roaches to ceiling leaks and they had it taken down saying it was false It wasnt false it was a night mare"),
    ("super!", "The wings is the best sometimes the order is wrong but when I want crispy they give it to me The workers have always been nice and I just enjoy rallys all together"),
    ("super!", "We stayed here for three nights From the time we walked into the lobby the staff was quick to help and exceptionally friendly We stayed on the fifth floor which was a bit noisy because of the rooms around us had families with little kids as well as the atrium just outside our door The hotel offers a happy hour where guests can get free drinks and snacks as well as a free hot breakfast and a shuttle bus to the front gate of Busch Gardens"),
    ("super!", "I spent hours yesterday trading in old phones for store credit and then purchasing a new I phone The process was long with many steps A young lady by the name of Darian helped us through the whole process She had the sweetest attidude with great customer service I learned she was supposed to get off at but was still with us at pm After the purchase she even helped us to pick out the right case for the phone There are not too many people left like this young lady Thank you"),
    ("super!", "I went in there tonight at around pm I was planning on putting down a decent amount of money to expand my board game collection Unfortunately I could not Why Because there were too many people in the store well more like too many tables They had three rows of tables tables deep to host their magic tournament I tried to go around the perimeter of the tables to look at the games but couldnt because either the people who were playing had their items in the way or there were people standing in the way they wouldnt move either The website said the tournament didnt start until These people were already well into their games it was clear they arent sticking to a schedule Id like to know when it is possible to actually shop in this store They charge for the tournament with about people in there tonight they made about what bucks I would have happily dropped that and more in the store tonight Instead theyve lost a customer Ill take my money elsewhere it is fine")
]

# Writing data to a text file
with open('reviews_and_summaries.txt', 'w') as f:
    for i, (review, summary) in enumerate(reviews_and_summaries, start=1):
        f.write(f"Prompt {i}:\n")
        f.write(f"Given this review, is the sentiment positive or negative?\n")
        f.write(f"Review: {review}\n")
        f.write(f"Summary: {summary}\n")
        f.write("Sentiment: Positive\n\n")  # Assuming all sentiments are positive, you can adjust this as needed



# data_zero_shot = data_zero_shot.rename(columns={'input_text': 'zero_shot_prompt'})
# data_zero_shot = data_zero_shot.head(6)

with open('sample_text.txt', 'r') as file:
    sample_text = file.read()

data_zero_shot['k_shot_prompt'] = sample_text + ' ' + data_zero_shot['zero_shot_prompt']

save_path = '/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/Prompts/K_shot/k_shot_prompting.csv'
data_zero_shot.to_csv(save_path, index=False) 
