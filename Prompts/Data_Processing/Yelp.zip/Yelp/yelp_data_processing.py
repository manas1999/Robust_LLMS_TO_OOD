import pandas as pd
import random

# Load the dataset
reviews = pd.read_csv('/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/yelp_reviews_cleaned.csv')
labels =  pd.read_csv('/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/yelp_reviews_sentiment.csv')

data = pd.concat([reviews, labels], axis=1)

save_path = '/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/yelp_reviews_processed.csv'
data.to_csv(save_path, index=False) 

print("data columns:", data.columns)
print("data sentiment unique terms:", data['Sentiment'].unique())

data_positive = data[data["Sentiment"] == "positive"]
selected_positive_rows = data_positive.sample(n= 10000, random_state=40)

data_negative = data[data["Sentiment"] == "negative"]
selected_negative_rows = data_negative.sample(n= 10000, random_state=40)

combined_df = pd.concat([selected_positive_rows, selected_negative_rows], ignore_index=True)

save_path_1 = '/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/yelp_reviews_processed_top_20k.csv'
data_1 = combined_df
data_1.to_csv(save_path_1, index=False) 


## processing flipcart data 
flipcart_reviews = pd.read_csv('/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/yelp_reviews_cleaned.csv')
flipcart_labels =  pd.read_csv('/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/flipkart_labels.csv')
flipcart_prompts =  pd.read_csv('/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/flipcart_prompts.csv')

flipcart_data = pd.concat([flipcart_reviews, flipcart_labels, flipcart_prompts], axis=1)

save_path = '/Users/priyayarrabolu/Desktop/Priya/Spring_24/685/Project/Datasets/yelp_reviews_processed.csv'
data.to_csv(save_path, index=False) 